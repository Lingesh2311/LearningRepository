# Portfolio Analytics: AI/BI dashboard demo

An AI/BI dashboard where business users pick values from dropdowns and type amounts
into a text box. The SQL behind it builds temporary views, calls a Unity Catalog
function for a what-if scenario, and returns the result. Users see results only.

All data is synthetic: 500 trading positions, 100 risk factors and 48 desk rows.
The firm names, desks and people are invented.

## Contents

| File | What it is |
|---|---|
| `setup_portfolio_analytics.py` | Databricks notebook. Builds everything and publishes the dashboard |
| `portfolio_analytics.lvdash.json` | The dashboard on its own, for manual import (see the end of this file) |
| `README.md` | This file |

## Before you start

- A Unity Catalog catalog you can use. The notebook creates a schema inside it, and
  does not create catalogs.
- `USE CATALOG` and `CREATE SCHEMA` on that catalog. If you pick a schema that exists
  already, you need `USE SCHEMA`, `CREATE TABLE` and `CREATE FUNCTION` on it.
- A SQL warehouse, serverless or pro, that you can use.
- Compute for the notebook. Serverless works.

## Install (3 steps)

1. **Import the notebook.** In the workspace, open **Workspace**, go to your folder,
   click the kebab menu, then **Import**. Pick **File** and drop in
   `setup_portfolio_analytics.py`. Import only this file, not the zip.
2. **Fill in the widgets** at the top of the notebook:
   - `catalog`: your catalog, for example `main`
   - `schema`: keep `portfolio_analytics_demo` or type another name
   - `warehouse_id`: leave blank to use a serverless SQL warehouse
3. **Click Run all.** It takes 1 to 2 minutes. The last cell prints two links:
   - **Draft**: the editable dashboard, for authors
   - **Published**: the read-only view to share with business users

The dashboard lands in `/Users/<you>/portfolio-analytics-demo/` as
"Portfolio Analytics (<schema>)". Run the notebook again at any time: it replaces the
data, the function and the dashboard in place, so the links stay the same.

## What the notebook creates

| Object | Description |
|---|---|
| `<catalog>.<schema>.positions` | 500 positions: desk, region, product type, notional, market value, PnL, dates, counterparty |
| `<catalog>.<schema>.risk_factors` | 100 risk factors with sensitivity and category, per region |
| `<catalog>.<schema>.reference_data` | 48 rows: desk head and cost center per desk, region and product |
| `<catalog>.<schema>.stress_impact()` | The scenario rule: exposure x sensitivity x shock / factors in scope |
| Dashboard "Portfolio Analytics (<schema>)" | 12 datasets, 1 page, published with embedded credentials |

Every table, column and the function carry descriptions, so Genie and Catalog
Explorer explain them.

## What to try on the dashboard

| Input | Try | You should see |
|---|---|---|
| Region, Product Type | Americas + Equities, then EMEA + Fixed Income | Tiles, Risk Overlay and Position Detail change |
| Min Notional (text box) | `300M`, `$800,000,000`, `1B`, `abc` | Risk Overlay narrows. `abc` reads as 0, no error |
| View Selector | by_region, by_product, by_desk | The bar chart switches to another grouping |
| Market Shock | -20, then 0 | Stressed PnL by Desk moves. At 0 base and stressed are equal |
| Risk Category, Measure | Credit Risk, Notional | Only the scenario chart and Risk Overlay change |

## How the pattern works

Each dataset is one SQL query with named parameters (`:selected_region`,
`:min_notional`, ...). Filter widgets feed those parameters. Temporary views stand in
for the temp tables a classic BI tool builds, and they exist only for one query run.
`IDENTIFIER(:view_name)` lets the user choose which view runs. To point the dashboard
at your own tables, change the `FROM` clauses in the datasets and keep the parameters.

## Remove everything

```sql
DROP SCHEMA <catalog>.<schema> CASCADE;
```

Then move the dashboard to Trash from the Dashboards page.

## Manual import (if the notebook cannot create the dashboard)

Run the notebook first, so the tables exist. Then replace every `${catalog}.${schema}`
in `portfolio_analytics.lvdash.json` with your names, for example on macOS or Linux:

```bash
sed -i.bak 's/\${catalog}\.\${schema}/main.portfolio_analytics_demo/g' portfolio_analytics.lvdash.json
```

In the workspace open **Dashboards**, click the arrow next to **Create dashboard**,
choose **Import dashboard from file**, and pick the edited file. Then choose a SQL
warehouse and click **Publish**.

## Limits

- Dashboards are read-only. Nothing a user does writes back to the tables.
- Viewers of the published link run queries with the publisher's credentials.
