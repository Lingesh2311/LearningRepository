# Databricks notebook source
# MAGIC %md
# MAGIC # Portfolio Analytics: setup
# MAGIC
# MAGIC Builds a synthetic trading book and an AI/BI dashboard on top of it, in a schema you choose.
# MAGIC All data is invented: 500 positions, 100 risk factors, 48 desk rows.
# MAGIC
# MAGIC 1. Fill in the widgets at the top of the page.
# MAGIC    * `catalog`: an existing Unity Catalog catalog. This notebook does not create catalogs.
# MAGIC    * `schema`: created if it does not exist.
# MAGIC    * `warehouse_id`: leave blank to use a serverless SQL warehouse.
# MAGIC 2. Click **Run all**. The last cell prints the dashboard links.
# MAGIC
# MAGIC Running it again replaces the tables, the function and the dashboard in place.

# COMMAND ----------

dbutils.widgets.text("catalog", "", "1. Catalog (must exist)")
dbutils.widgets.text("schema", "portfolio_analytics_demo", "2. Schema")
dbutils.widgets.text("warehouse_id", "", "3. SQL warehouse ID (blank = auto)")

# COMMAND ----------

# MAGIC %md ## 1. Check the target

# COMMAND ----------

import re

CATALOG = dbutils.widgets.get("catalog").strip()
SCHEMA = dbutils.widgets.get("schema").strip()
if not CATALOG:
    raise ValueError("Set the catalog widget to an existing Unity Catalog catalog, then run again.")
for label, value in (("catalog", CATALOG), ("schema", SCHEMA)):
    if not re.fullmatch(r"[A-Za-z0-9_-]+", value):
        raise ValueError(f"{label} {value!r}: use letters, digits, _ or - only.")
if CATALOG.lower() in ("hive_metastore", "spark_catalog"):
    raise ValueError("Pick a Unity Catalog catalog. The dashboard calls a Unity Catalog function.")
if CATALOG not in [r[0] for r in spark.sql("SHOW CATALOGS").collect()]:
    raise ValueError(f"Catalog {CATALOG} not found, or you cannot see it. This notebook does not create "
                     "catalogs. Run SHOW CATALOGS to list the ones you can use.")

PH = "${catalog}.${schema}"
FQ = f"`{CATALOG}`.`{SCHEMA}`"
print(f"Target: {FQ}")

# COMMAND ----------

# MAGIC %md ## 2. Tables and synthetic data

# COMMAND ----------

import random
from datetime import date, timedelta

SEED = 20261015

SCHEMA_COMMENT = 'Synthetic trading book for the Portfolio Analytics AI/BI dashboard. positions holds what the bank owns, risk_factors what could move its value, reference_data who runs each desk. by_region, by_product and by_desk are whole-book totals used by the dashboard View Selector. All money is USD.'

DESKS = [('US Equity Flow', ['Americas'], ['Equities', 'Derivatives', 'Structured Products']),
 ('US HY Trading', ['Americas'], ['Fixed Income', 'Derivatives', 'Structured Products']),
 ('US Private Client', ['Americas'], ['Equities', 'Fixed Income', 'Structured Products', 'FX']),
 ('LatAm FX', ['Americas'], ['FX', 'Derivatives']),
 ('Private Markets', ['Americas', 'EMEA'], ['Equities', 'Fixed Income', 'Structured Products']),
 ('Global Macro', ['Americas', 'EMEA', 'APAC'], ['Equities', 'Fixed Income', 'FX', 'Derivatives']),
 ('Quant Strategies', ['Americas', 'EMEA', 'APAC'], ['Equities', 'FX', 'Derivatives']),
 ('EMEA Credit', ['EMEA'], ['Fixed Income', 'Structured Products', 'Derivatives']),
 ('APAC Rates', ['APAC'], ['Fixed Income', 'FX', 'Derivatives']),
 ('APAC Equity Flow', ['APAC'], ['Equities', 'Structured Products', 'Derivatives'])]

DESK_HEADS = {'APAC Equity Flow': 'Mei Lin Chua',
 'APAC Rates': 'Kenji Tanaka',
 'EMEA Credit': 'Henrik Johansson',
 'Global Macro': 'Sophie Laurent',
 'LatAm FX': 'Carolina Mendes',
 'Private Markets': 'Thomas Whitfield',
 'Quant Strategies': 'Arjun Mehta',
 'US Equity Flow': 'Michael Brennan',
 'US HY Trading': 'Rachel Goldstein',
 'US Private Client': 'David Okafor'}

REGION_WEIGHTS = {'Americas': 0.55, 'EMEA': 0.25, 'APAC': 0.2}

PRODUCT_NOTIONAL = {'Derivatives': (9000000, 1.2),
 'Equities': (18000000, 1.1),
 'FX': (6000000, 1.0),
 'Fixed Income': (12000000, 1.0),
 'Structured Products': (4000000, 0.9)}

PRODUCT_WEIGHTS = {'Derivatives': 1.5, 'Equities': 3.0, 'FX': 1.2, 'Fixed Income': 2.0, 'Structured Products': 1.0}

COUNTERPARTIES = ['Northwind Capital', 'Harbor Point AM', 'Bluefin Asset Partners', 'Cedar Ridge Pension',
 'Granite Peak Investors', 'Silverline Fund Services', 'Oakmont Securities', 'Lakeside Advisors',
 'Redwood Treasury', 'Summit Crest Bank', 'Ironbridge Markets', 'Meridian Vale AM', 'Copperleaf Partners',
 'Westgate Holdings', 'Aurora Fields Capital', 'Halcyon Bay Fund', 'Kestrel Point Bank',
 'Tidewater Pension Trust', 'Larkspur Investments', 'Fernhill Capital', 'Stonehaven AM',
 'Brightwater Securities', 'Pinecrest Endowment', 'Riverbend Insurance', 'Ashford Lane Partners',
 'Driftwood Macro Fund', 'Quillstone Bank', 'Elmstead Sovereign Fund']

RISK_FACTORS = {'APAC': [('JPY Interest Rate {t}', 'Market Risk', ['2Y', '10Y']),
          ('AUD Interest Rate {t}', 'Market Risk', ['3Y', '10Y']),
          ('CNY Interest Rate 5Y', 'Market Risk', [None]),
          ('APAC Equity Vol {t}', 'Market Risk', ['Nikkei', 'Hang Seng', 'ASX']),
          ('FX Spot {t}', 'Market Risk', ['USDJPY', 'USDCNH', 'AUDUSD', 'USDSGD']),
          ('Asia IG Credit Spread', 'Credit Risk', [None]),
          ('China Property Credit Spread', 'Credit Risk', [None]),
          ('APAC HY Default Rate', 'Credit Risk', [None]),
          ('Asia Sovereign Spread {t}', 'Credit Risk', ['Indonesia', 'Philippines']),
          ('JGB Market Depth', 'Liquidity Risk', [None]),
          ('Offshore CNH Liquidity', 'Liquidity Risk', [None]),
          ('APAC Repo Funding Spread', 'Liquidity Risk', [None]),
          ('Cross-Border Settlement', 'Operational Risk', [None]),
          ('Model Risk {t}', 'Operational Risk', ['Rates', 'Equity']),
          ('Data Residency Breach', 'Operational Risk', [None]),
          ('APAC Credit Spread {t}', 'Credit Risk', ['Korea', 'India', 'Australia']),
          ('Commodity Price {t}', 'Market Risk', ['Iron Ore', 'LNG', 'Palm Oil'])],
 'Americas': [('USD Interest Rate {t}', 'Market Risk', ['2Y', '5Y', '10Y', '30Y']),
              ('US Equity Vol {t}', 'Market Risk', ['1M', '3M', '1Y']),
              ('S&P 500 Spot', 'Market Risk', [None]),
              ('US IG Credit Spread {t}', 'Credit Risk', ['3Y', '5Y', '10Y']),
              ('US HY Default Rate {t}', 'Credit Risk', ['1Y', '3Y']),
              ('LatAm Sovereign Spread {t}', 'Credit Risk', ['Brazil', 'Mexico', 'Chile']),
              ('EM FX Spot {t}', 'Market Risk', ['BRL', 'MXN', 'CLP', 'COP']),
              ('US Treasury Bid-Ask {t}', 'Liquidity Risk', ['On-the-run', 'Off-the-run']),
              ('US HY Bond Liquidity', 'Liquidity Risk', [None]),
              ('Repo Funding Spread {t}', 'Liquidity Risk', ['O/N', '1M', '3M']),
              ('Muni Market Depth', 'Liquidity Risk', [None]),
              ('Trade Settlement Failure', 'Operational Risk', [None]),
              ('Model Risk {t}', 'Operational Risk', ['Equity', 'Rates', 'Credit']),
              ('Cyber Event', 'Operational Risk', [None]),
              ('Vendor Outage', 'Operational Risk', [None]),
              ('Commodity Price {t}', 'Market Risk', ['WTI', 'Gold', 'Copper']),
              ('Mortgage Prepayment Speed', 'Market Risk', [None]),
              ('CDX IG Index', 'Credit Risk', [None]),
              ('CDX HY Index', 'Credit Risk', [None]),
              ('Client Concentration', 'Operational Risk', [None])],
 'EMEA': [('EUR Interest Rate {t}', 'Market Risk', ['2Y', '5Y', '10Y']),
          ('GBP Interest Rate {t}', 'Market Risk', ['2Y', '10Y']),
          ('CHF Interest Rate 5Y', 'Market Risk', [None]),
          ('EUR Credit Spread {t}', 'Credit Risk', ['IG', 'HY', 'Financials']),
          ('Italy BTP-Bund Spread', 'Credit Risk', [None]),
          ('iTraxx Main Index', 'Credit Risk', [None]),
          ('iTraxx Crossover Index', 'Credit Risk', [None]),
          ('EMEA Equity Vol {t}', 'Market Risk', ['Euro Stoxx', 'FTSE', 'SMI']),
          ('FX Spot {t}', 'Market Risk', ['EURUSD', 'GBPUSD', 'USDCHF']),
          ('Covered Bond Liquidity', 'Liquidity Risk', [None]),
          ('EUR Repo Funding Spread', 'Liquidity Risk', [None]),
          ('ECB Collateral Haircut', 'Liquidity Risk', [None]),
          ('EMEA Corporate Bond Depth', 'Liquidity Risk', [None]),
          ('Regulatory Change {t}', 'Operational Risk', ['MiFID', 'Basel IV']),
          ('Trade Reporting Breach', 'Operational Risk', [None]),
          ('Model Risk {t}', 'Operational Risk', ['Credit', 'FX']),
          ('Sovereign Default {t}', 'Credit Risk', ['Turkey', 'Egypt', 'South Africa'])]}

TABLES = {'positions': ('One row per trading position in a synthetic trading book. 500 positions, traded over the 24 '
               'months before the build date. All money is USD.\n'
               '\n'
               'Who and where. position_id identifies the position. desk is the trading team that owns it '
               '(10 desks, e.g. US Equity Flow, Global Macro). region is where it is booked (Americas, EMEA, '
               'APAC). product_type is the asset class (Equities, Fixed Income, Derivatives, FX, Structured '
               'Products). A desk trades a fixed set of region and product_type pairs, and each desk, region '
               'and product_type combination has exactly one row in reference_data with the desk head and '
               'cost center. counterparty is the institution on the other side of the trade (28 names, e.g. '
               'Northwind Capital, Granite Peak Investors).\n'
               '\n'
               'How much. The three money columns describe the same position three ways. notional_value is '
               'the face size the trade references (523K to 373M). market_value is what it is worth today: '
               '85 to 115 percent of notional for Equities, Fixed Income, FX and Structured Products, 2 to '
               '15 percent of notional for Derivatives. pnl is profit or loss to date, roughly in proportion '
               'to notional, negative for 150 of the 500 positions. Sum notional_value for exposure (11.49B '
               'in total), market_value for current worth (9.58B), pnl for performance (102.9M). Never add '
               'the three together.\n'
               '\n'
               'When. trade_date is when the position opened. maturity_date is when it ends, 1 to 10 years '
               'later. A position is open between the two dates.\n'
               '\n'
               'Joins. reference_data on desk, region and product_type together, otherwise rows repeat. '
               'risk_factors on region only, which pairs each position with every factor in its region (40 '
               'for Americas, 30 for EMEA and APAC), so total positions first and join after, or sums are '
               'overstated.\n'
               '\n'
               'Shape. Americas holds 253 positions, EMEA 135, APAC 112. Equities carries the largest '
               'notional (7.04B of 11.49B).',
               [('position_id', 'INT', 'Unique position identifier. Primary key.'),
                ('region', 'STRING', 'Booking region. One of Americas, EMEA, APAC.'),
                ('product_type',
                 'STRING',
                 'Asset class. One of Equities, Fixed Income, Derivatives, FX, Structured Products.'),
                ('desk',
                 'STRING',
                 'Trading desk that owns the position, e.g. US Equity Flow, Global Macro. Joins to '
                 'reference_data.desk.'),
                ('notional_value',
                 'DOUBLE',
                 'Notional amount in USD. Face value the position references, not its current worth.'),
                ('market_value',
                 'DOUBLE',
                 'Current market value in USD. For derivatives this is a small fraction of notional.'),
                ('pnl', 'DOUBLE', 'Profit and loss to date in USD. Negative means a loss.'),
                ('trade_date', 'DATE', 'Date the position was opened. Covers the last 24 months.'),
                ('maturity_date', 'DATE', 'Date the position matures, 1 to 10 years after trade_date.'),
                ('counterparty',
                 'STRING',
                 'Institution on the other side of the trade, e.g. Northwind Capital, Granite Peak '
                 'Investors.')]),
 'reference_data': ('Desk directory. 48 rows, one per desk, region and product_type combination that the '
                    'bank trades. 10 desks, each with one desk_head, and a unique cost_center per row.\n'
                    '\n'
                    'desk is the trading team. region and product_type list where and what the desk trades. '
                    'A desk appears once for each pair it covers, so Global Macro, which trades 4 products '
                    'in 3 regions, has 12 rows. desk_head is the person who runs the desk. cost_center is '
                    'the finance code the row books to (CC-NNNN).\n'
                    '\n'
                    'Joins to positions on desk, region and product_type together. Every position matches '
                    'exactly one row. Joining on desk alone repeats each position once per region and '
                    'product the desk covers.',
                    [('desk', 'STRING', 'Trading desk name. Join key to positions.desk.'),
                     ('desk_head', 'STRING', 'Person who runs the desk.'),
                     ('cost_center', 'STRING', 'Finance cost center code, format CC-NNNN.'),
                     ('region', 'STRING', 'Region the desk trades in. Join key to positions.region.'),
                     ('product_type',
                      'STRING',
                      'Asset class the desk trades in that region. Join key to positions.product_type.')]),
 'risk_factors': ('One row per risk factor per region. 100 synthetic factors: Americas 40, EMEA 30, APAC 30. '
                  'Lists what could move the value of the positions in the positions table.\n'
                  '\n'
                  'factor_name is the specific driver (e.g. USD Interest Rate 10Y, iTraxx Main Index, FX '
                  'Spot USDJPY). factor_category groups it: Market Risk 43, Credit Risk 27, Operational Risk '
                  '16, Liquidity Risk 14. region is the part of the book it applies to. sensitivity, from -1 '
                  'to 1, is how strongly and in which direction the factor moves a position: risk-weighted '
                  'exposure = positions.notional_value x sensitivity. Positive and negative sensitivities '
                  'offset. confidence_level, 0.90 to 0.99, is how reliable the sensitivity estimate is.\n'
                  '\n'
                  'Joins to positions on region only. Every position pairs with every factor in its region, '
                  'so total positions by desk or region first, then join. The dashboard risk overlay totals '
                  'notional per factor and desk this way.',
                  [('factor_id', 'INT', 'Unique risk factor identifier. Primary key.'),
                   ('factor_name',
                    'STRING',
                    'Risk factor, e.g. USD Interest Rate 10Y, EUR Credit Spread HY, FX Spot USDJPY.'),
                   ('factor_category',
                    'STRING',
                    'One of Market Risk, Credit Risk, Liquidity Risk, Operational Risk.'),
                   ('sensitivity',
                    'DOUBLE',
                    'Exposure sensitivity from -1 to 1. Notional x sensitivity gives risk-weighted exposure. '
                    'Sign shows direction.'),
                   ('confidence_level',
                    'DOUBLE',
                    'Statistical confidence of the factor estimate, 0.90 to 0.99.'),
                   ('region',
                    'STRING',
                    'Region the factor applies to. One of Americas, EMEA, APAC. Join key to '
                    'positions.region.')])}


def sql_str(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"


def build_reference_data() -> list[tuple]:
    rows = []
    cc = 4100
    for desk, regions, products in DESKS:
        for region in regions:
            for product in products:
                cc += 7
                rows.append((desk, DESK_HEADS[desk], f"CC-{cc}", region, product))
    return rows


def build_risk_factors(rng: random.Random) -> list[tuple]:
    rows = []
    factor_id = 1
    for region, templates in RISK_FACTORS.items():
        for name_tpl, category, buckets in templates:
            for bucket in buckets:
                name = name_tpl.format(t=bucket) if bucket else name_tpl
                rows.append((
                    factor_id,
                    name,
                    category,
                    round(rng.uniform(-1.0, 1.0), 3),
                    round(rng.uniform(0.90, 0.99), 3),
                    region,
                ))
                factor_id += 1
    return rows


def build_positions(rng: random.Random, ref_rows: list[tuple], n: int = 500) -> list[tuple]:
    today = date.today()
    combos_by_region: dict[str, list[tuple]] = {}
    for desk, _head, _cc, region, product in ref_rows:
        combos_by_region.setdefault(region, []).append((desk, product))

    regions = list(REGION_WEIGHTS)
    rows = []
    for position_id in range(1, n + 1):
        region = rng.choices(regions, weights=[REGION_WEIGHTS[r] for r in regions])[0]
        combos = combos_by_region[region]
        desk, product = rng.choices(combos, weights=[PRODUCT_WEIGHTS[p] for _, p in combos])[0]

        median, sigma = PRODUCT_NOTIONAL[product]
        notional = min(max(rng.lognormvariate(0, sigma) * median, 100_000), 500_000_000)

        if product == "Derivatives":
            market_value = notional * rng.uniform(0.02, 0.15)
        else:
            market_value = notional * rng.uniform(0.85, 1.15)

        # Mostly positive return on notional, loosely scaled with size.
        pnl = notional * rng.gauss(0.006, 0.015)
        pnl = min(max(pnl, -5_000_000), 10_000_000)

        trade_date = today - timedelta(days=rng.randint(0, 729))
        maturity_date = trade_date + timedelta(days=rng.randint(365, 3650))

        rows.append((
            position_id,
            region,
            product,
            desk,
            round(notional, 2),
            round(market_value, 2),
            round(pnl, 2),
            trade_date.isoformat(),
            maturity_date.isoformat(),
            rng.choice(COUNTERPARTIES),
        ))
    return rows



spark.sql(f"CREATE SCHEMA IF NOT EXISTS {FQ}")
spark.sql(f"COMMENT ON SCHEMA {FQ} IS {sql_str(SCHEMA_COMMENT)}")
for name, (comment, columns) in TABLES.items():
    cols = ",\n  ".join(f"{c} {t} COMMENT {sql_str(d)}" for c, t, d in columns)
    spark.sql(f"CREATE OR REPLACE TABLE {FQ}.{name} (\n  {cols}\n) COMMENT {sql_str(comment)}")

rng = random.Random(SEED)
ref_rows = build_reference_data()
factor_rows = build_risk_factors(rng)
position_rows = build_positions(rng, ref_rows)

spark.sql(f"INSERT INTO {FQ}.reference_data VALUES " + ", ".join(
    f"({sql_str(d)}, {sql_str(h)}, {sql_str(c)}, {sql_str(r)}, {sql_str(p)})" for d, h, c, r, p in ref_rows))
spark.sql(f"INSERT INTO {FQ}.risk_factors VALUES " + ", ".join(
    f"({i}, {sql_str(n)}, {sql_str(c)}, {s}, {cl}, {sql_str(r)})" for i, n, c, s, cl, r in factor_rows))
spark.sql(f"INSERT INTO {FQ}.positions VALUES " + ", ".join(
    f"({i}, {sql_str(r)}, {sql_str(p)}, {sql_str(d)}, {n}, {mv}, {pnl}, DATE'{td}', DATE'{md}', {sql_str(cp)})"
    for i, r, p, d, n, mv, pnl, td, md, cp in position_rows))
print(f"Loaded {len(position_rows)} positions, {len(factor_rows)} risk factors, {len(ref_rows)} desk rows")

# COMMAND ----------

# MAGIC %md ## 3. Scenario rule as a Unity Catalog function

# COMMAND ----------

STRESS_IMPACT = """
CREATE OR REPLACE FUNCTION ${catalog}.${schema}.stress_impact(
  exposure DOUBLE COMMENT 'Notional exposure in USD, e.g. SUM(positions.notional_value) for a desk',
  sensitivity DOUBLE COMMENT 'risk_factors.sensitivity, -1 to 1. Sign gives the direction of the move',
  shock_pct INT COMMENT 'Market shock in percent, e.g. -20 for a 20 percent fall',
  factors_in_scope INT COMMENT 'Number of risk factors the shock applies to. Exposure is spread evenly across them'
)
RETURNS DOUBLE
COMMENT 'Scenario rule. USD profit or loss that one risk factor adds to a position under a market shock. Formula: exposure x sensitivity x shock_pct / 100 / factors_in_scope. Summing the result over every factor in scope gives the total stress impact, which is added to base pnl to get stressed pnl. Called by the dashboard Risk Overlay and Stressed PnL by Desk.'
RETURN exposure * sensitivity * (shock_pct / 100.0) / factors_in_scope
"""
spark.sql(STRESS_IMPACT.replace(PH, FQ))
print(f"Created {FQ}.stress_impact")

# COMMAND ----------

# MAGIC %md ## 4. Dashboard: create or update, then publish

# COMMAND ----------

import json
from databricks.sdk import WorkspaceClient
from databricks.sdk.errors import NotFound

DASHBOARD_JSON = r'''{
  "datasets": [
    {
      "name": "portfolio_summary",
      "displayName": "Portfolio summary (risk overlay)",
      "queryLines": [
        "-- Risk overlay for the selected region and product, with a what-if scenario on top.\n",
        "-- Same flow as a BI tool that builds temp tables in the source database, joins them\n",
        "-- and returning a summary. Each step reads the one before it.\n",
        "-- Temp views exist only for this query run and write nothing to the source,\n",
        "-- so the same SQL runs on a read-only federated catalog.\n",
        "-- Inputs: Region, Product Type, Min Notional (free text), and the scenario inputs\n",
        "-- Market Shock, Risk Category and Measure.\n",
        "\n",
        "-- step 0: read the Min Notional input. It is free text, so accept 50000000, 50M,\n",
        "-- 2.5m, $50,000,000 or 750K. Anything unreadable means no threshold (0).\n",
        "CREATE TEMPORARY VIEW min_notional_input AS\n",
        "SELECT COALESCE(\n",
        "  CASE\n",
        "    WHEN s RLIKE '^[0-9]+([.][0-9]+)?[KMB]$'\n",
        "      THEN TRY_CAST(LEFT(s, LENGTH(s) - 1) AS DOUBLE)\n",
        "           * CASE RIGHT(s, 1) WHEN 'K' THEN 1e3 WHEN 'M' THEN 1e6 ELSE 1e9 END\n",
        "    ELSE TRY_CAST(s AS DOUBLE)\n",
        "  END, 0) AS min_notional_usd\n",
        "FROM (SELECT UPPER(REGEXP_REPLACE(TRIM(:min_notional), '[$, ]', '')) AS s);\n",
        "\n",
        "-- step 1: positions for the chosen region and product.\n",
        "-- Filter first so a federated source pushes the WHERE down and returns only this slice.\n",
        "CREATE TEMPORARY VIEW filtered_positions AS\n",
        "SELECT *\n",
        "FROM ${catalog}.${schema}.positions\n",
        "WHERE region = :selected_region\n",
        "  AND product_type = :selected_product;\n",
        "\n",
        "-- step 2: risk factors the scenario applies to. All, or one category.\n",
        "-- factors_in_scope spreads each desk's exposure evenly across these factors.\n",
        "CREATE TEMPORARY VIEW factors_in_scope AS\n",
        "SELECT *, COUNT(*) OVER () AS factors_in_scope\n",
        "FROM ${catalog}.${schema}.risk_factors\n",
        "WHERE region = :selected_region\n",
        "  AND (:risk_category = 'All' OR factor_category = :risk_category);\n",
        "\n",
        "-- step 3: join the slice to those factors, total per factor and desk.\n",
        "-- Some federated sources do not push joins down, so this runs on Databricks on the slice.\n",
        "-- stress_impact is the governed UC function holding the scenario rule.\n",
        "CREATE TEMPORARY VIEW risk_overlay AS\n",
        "SELECT\n",
        "  r.factor_category,\n",
        "  r.factor_name,\n",
        "  r.sensitivity,\n",
        "  p.desk,\n",
        "  SUM(p.notional_value) AS total_notional,\n",
        "  SUM(p.notional_value) * r.sensitivity AS risk_weighted_exposure,\n",
        "  SUM(p.pnl) AS total_pnl,\n",
        "  COUNT(*) AS position_count,\n",
        "  ${catalog}.${schema}.stress_impact(SUM(p.notional_value), r.sensitivity, :shock_pct, CAST(r.factors_in_scope AS INT)) AS stress_impact\n",
        "FROM filtered_positions p\n",
        "JOIN factors_in_scope r\n",
        "  ON p.region = r.region\n",
        "GROUP BY r.factor_category, r.factor_name, r.sensitivity, r.factors_in_scope, p.desk;\n",
        "\n",
        "-- step 4: summary output. The Measure input picks what selected_measure holds,\n",
        "-- measure_name labels it. Keep rows above the parsed threshold, largest first.\n",
        "-- min_notional_applied shows how the typed value was read.\n",
        "SELECT\n",
        "  r.*,\n",
        "  CASE :measure\n",
        "    WHEN 'Notional' THEN total_notional\n",
        "    WHEN 'Risk-weighted exposure' THEN risk_weighted_exposure\n",
        "    ELSE stress_impact\n",
        "  END AS selected_measure,\n",
        "  :measure AS measure_name,\n",
        "  t.min_notional_usd AS min_notional_applied\n",
        "FROM risk_overlay r\n",
        "CROSS JOIN min_notional_input t\n",
        "WHERE total_notional > t.min_notional_usd\n",
        "ORDER BY ABS(selected_measure) DESC;\n"
      ],
      "parameters": [
        {
          "displayName": "selected_region",
          "keyword": "selected_region",
          "dataType": "STRING",
          "defaultSelection": {
            "values": {
              "dataType": "STRING",
              "values": [
                {
                  "value": "Americas"
                }
              ]
            }
          }
        },
        {
          "displayName": "selected_product",
          "keyword": "selected_product",
          "dataType": "STRING",
          "defaultSelection": {
            "values": {
              "dataType": "STRING",
              "values": [
                {
                  "value": "Equities"
                }
              ]
            }
          }
        },
        {
          "displayName": "min_notional",
          "keyword": "min_notional",
          "dataType": "STRING",
          "defaultSelection": {
            "values": {
              "dataType": "STRING",
              "values": [
                {
                  "value": "1000000"
                }
              ]
            }
          }
        },
        {
          "displayName": "shock_pct",
          "keyword": "shock_pct",
          "dataType": "INTEGER",
          "defaultSelection": {
            "values": {
              "dataType": "INTEGER",
              "values": [
                {
                  "value": "-20"
                }
              ]
            }
          }
        },
        {
          "displayName": "risk_category",
          "keyword": "risk_category",
          "dataType": "STRING",
          "defaultSelection": {
            "values": {
              "dataType": "STRING",
              "values": [
                {
                  "value": "All"
                }
              ]
            }
          }
        },
        {
          "displayName": "measure",
          "keyword": "measure",
          "dataType": "STRING",
          "defaultSelection": {
            "values": {
              "dataType": "STRING",
              "values": [
                {
                  "value": "Stress impact"
                }
              ]
            }
          }
        }
      ]
    },
    {
      "name": "portfolio_kpis",
      "displayName": "Portfolio KPIs (monthly)",
      "queryLines": [
        "-- Totals for the Total Notional and Total PnL tiles.\n",
        "-- Same first step as the risk overlay. Positions filtered to the chosen region and product.\n",
        "-- Kept out of the risk overlay dataset because its join repeats each position once per\n",
        "-- risk factor (40 in Americas). Summing there would overstate the book about 40x.\n",
        "-- One row per trade month. Each tile sums the rows.\n",
        "\n",
        "-- step 1: positions for the chosen region and product.\n",
        "CREATE TEMPORARY VIEW filtered_positions AS\n",
        "SELECT *\n",
        "FROM ${catalog}.${schema}.positions\n",
        "WHERE region = :selected_region\n",
        "  AND product_type = :selected_product;\n",
        "\n",
        "-- step 2: monthly totals.\n",
        "SELECT\n",
        "  DATE_TRUNC('MONTH', trade_date) AS trade_month,\n",
        "  SUM(notional_value) AS total_notional,\n",
        "  SUM(pnl) AS total_pnl,\n",
        "  COUNT(*) AS position_count\n",
        "FROM filtered_positions\n",
        "GROUP BY 1\n",
        "ORDER BY 1;\n"
      ],
      "parameters": [
        {
          "displayName": "selected_region",
          "keyword": "selected_region",
          "dataType": "STRING",
          "defaultSelection": {
            "values": {
              "dataType": "STRING",
              "values": [
                {
                  "value": "Americas"
                }
              ]
            }
          }
        },
        {
          "displayName": "selected_product",
          "keyword": "selected_product",
          "dataType": "STRING",
          "defaultSelection": {
            "values": {
              "dataType": "STRING",
              "values": [
                {
                  "value": "Equities"
                }
              ]
            }
          }
        }
      ]
    },
    {
      "name": "dynamic_view",
      "displayName": "Dynamic view (IDENTIFIER)",
      "queryLines": [
        "-- Runtime choice of which report runs.\n",
        "-- In many BI tools the user picks the report layout as well as the filter values.\n",
        "-- Here each temp view holds one grouping of the whole book. The View Selector\n",
        "-- dropdown passes a view name and IDENTIFIER reads that string as the view to query.\n",
        "-- Every view names its grouping column dimension, so one bar chart draws any of them.\n",
        "-- View names must match the dropdown options exactly (case-sensitive).\n",
        "-- Whole book on purpose. The region and product filters do not apply here.\n",
        "\n",
        "-- grouping 1 of 3: by region.\n",
        "CREATE TEMPORARY VIEW by_region AS\n",
        "SELECT\n",
        "  region AS dimension,\n",
        "  COUNT(*) AS position_count,\n",
        "  SUM(notional_value) AS total_notional,\n",
        "  SUM(pnl) AS total_pnl,\n",
        "  AVG(market_value) AS avg_market_value\n",
        "FROM ${catalog}.${schema}.positions\n",
        "GROUP BY region;\n",
        "\n",
        "-- grouping 2 of 3: by product type.\n",
        "CREATE TEMPORARY VIEW by_product AS\n",
        "SELECT\n",
        "  product_type AS dimension,\n",
        "  COUNT(*) AS position_count,\n",
        "  SUM(notional_value) AS total_notional,\n",
        "  SUM(pnl) AS total_pnl,\n",
        "  AVG(market_value) AS avg_market_value\n",
        "FROM ${catalog}.${schema}.positions\n",
        "GROUP BY product_type;\n",
        "\n",
        "-- grouping 3 of 3: by desk.\n",
        "CREATE TEMPORARY VIEW by_desk AS\n",
        "SELECT\n",
        "  desk AS dimension,\n",
        "  COUNT(*) AS position_count,\n",
        "  SUM(notional_value) AS total_notional,\n",
        "  SUM(pnl) AS total_pnl,\n",
        "  AVG(market_value) AS avg_market_value\n",
        "FROM ${catalog}.${schema}.positions\n",
        "GROUP BY desk;\n",
        "\n",
        "-- run the view the user picked.\n",
        "SELECT * FROM IDENTIFIER(:view_name)\n",
        "ORDER BY total_notional DESC;\n"
      ],
      "parameters": [
        {
          "displayName": "view_name",
          "keyword": "view_name",
          "dataType": "STRING",
          "defaultSelection": {
            "values": {
              "dataType": "STRING",
              "values": [
                {
                  "value": "by_region"
                }
              ]
            }
          }
        }
      ]
    },
    {
      "name": "position_detail",
      "displayName": "Position detail",
      "queryLines": [
        "-- Drill-down. One row per position in the chosen slice, with desk head and cost center.\n",
        "-- The reporting step where a user checks the rows behind a summary.\n",
        "-- Joins on desk, region and product because reference_data holds one row per\n",
        "-- combination. Joining on fewer keys repeats positions.\n",
        "-- Desk = 'All' turns the desk filter off.\n",
        "SELECT\n",
        "  p.position_id,\n",
        "  p.region,\n",
        "  p.product_type,\n",
        "  p.desk,\n",
        "  p.notional_value,\n",
        "  p.market_value,\n",
        "  p.pnl,\n",
        "  p.trade_date,\n",
        "  p.maturity_date,\n",
        "  p.counterparty,\n",
        "  r.desk_head,\n",
        "  r.cost_center\n",
        "FROM ${catalog}.${schema}.positions p\n",
        "JOIN ${catalog}.${schema}.reference_data r\n",
        "  ON p.desk = r.desk AND p.region = r.region AND p.product_type = r.product_type\n",
        "WHERE p.region = :selected_region\n",
        "  AND p.product_type = :selected_product\n",
        "  AND (:selected_desk = 'All' OR p.desk = :selected_desk)\n",
        "ORDER BY p.notional_value DESC;\n"
      ],
      "parameters": [
        {
          "displayName": "selected_region",
          "keyword": "selected_region",
          "dataType": "STRING",
          "defaultSelection": {
            "values": {
              "dataType": "STRING",
              "values": [
                {
                  "value": "Americas"
                }
              ]
            }
          }
        },
        {
          "displayName": "selected_product",
          "keyword": "selected_product",
          "dataType": "STRING",
          "defaultSelection": {
            "values": {
              "dataType": "STRING",
              "values": [
                {
                  "value": "Equities"
                }
              ]
            }
          }
        },
        {
          "displayName": "selected_desk",
          "keyword": "selected_desk",
          "dataType": "STRING",
          "defaultSelection": {
            "values": {
              "dataType": "STRING",
              "values": [
                {
                  "value": "All"
                }
              ]
            }
          }
        }
      ]
    },
    {
      "name": "scenario_by_desk",
      "displayName": "Scenario: stressed PnL by desk",
      "queryLines": [
        "-- What-if result per desk for the selected region and product.\n",
        "-- Base pnl is what the desk has made to date. The scenario shocks every risk factor\n",
        "-- in scope by the chosen percent and adds the result. Stressed pnl = base + impact.\n",
        "-- Desks are totalled before the factor join, so pnl is not repeated per factor.\n",
        "-- Summing stress_impact per desk in the Risk Overlay gives the same figure.\n",
        "WITH desk_totals AS (\n",
        "  SELECT region, desk, SUM(notional_value) AS notional, SUM(pnl) AS base_pnl\n",
        "  FROM ${catalog}.${schema}.positions\n",
        "  WHERE region = :selected_region\n",
        "    AND product_type = :selected_product\n",
        "  GROUP BY region, desk\n",
        "),\n",
        "scope AS (\n",
        "  SELECT region, SUM(sensitivity) AS net_sensitivity, COUNT(*) AS factors_in_scope\n",
        "  FROM ${catalog}.${schema}.risk_factors\n",
        "  WHERE region = :selected_region\n",
        "    AND (:risk_category = 'All' OR factor_category = :risk_category)\n",
        "  GROUP BY region\n",
        ")\n",
        "SELECT\n",
        "  d.desk,\n",
        "  d.base_pnl,\n",
        "  ${catalog}.${schema}.stress_impact(d.notional, s.net_sensitivity, :shock_pct, CAST(s.factors_in_scope AS INT)) AS stress_impact,\n",
        "  d.base_pnl + ${catalog}.${schema}.stress_impact(d.notional, s.net_sensitivity, :shock_pct, CAST(s.factors_in_scope AS INT)) AS stressed_pnl\n",
        "FROM desk_totals d\n",
        "JOIN scope s ON d.region = s.region\n",
        "ORDER BY stressed_pnl\n"
      ],
      "parameters": [
        {
          "displayName": "selected_region",
          "keyword": "selected_region",
          "dataType": "STRING",
          "defaultSelection": {
            "values": {
              "dataType": "STRING",
              "values": [
                {
                  "value": "Americas"
                }
              ]
            }
          }
        },
        {
          "displayName": "selected_product",
          "keyword": "selected_product",
          "dataType": "STRING",
          "defaultSelection": {
            "values": {
              "dataType": "STRING",
              "values": [
                {
                  "value": "Equities"
                }
              ]
            }
          }
        },
        {
          "displayName": "shock_pct",
          "keyword": "shock_pct",
          "dataType": "INTEGER",
          "defaultSelection": {
            "values": {
              "dataType": "INTEGER",
              "values": [
                {
                  "value": "-20"
                }
              ]
            }
          }
        },
        {
          "displayName": "risk_category",
          "keyword": "risk_category",
          "dataType": "STRING",
          "defaultSelection": {
            "values": {
              "dataType": "STRING",
              "values": [
                {
                  "value": "All"
                }
              ]
            }
          }
        }
      ]
    },
    {
      "name": "opt_regions",
      "displayName": "Filter options: regions",
      "queryLines": [
        "-- Choices for the Region dropdown. Read from the data so new regions appear on their own.\n",
        "-- Feeds no chart.\n",
        "SELECT DISTINCT region\n",
        "FROM ${catalog}.${schema}.positions\n",
        "ORDER BY region\n"
      ]
    },
    {
      "name": "opt_products",
      "displayName": "Filter options: product types",
      "queryLines": [
        "-- Choices for the Product Type dropdown. Feeds no chart.\n",
        "SELECT DISTINCT product_type\n",
        "FROM ${catalog}.${schema}.positions\n",
        "ORDER BY product_type\n"
      ]
    },
    {
      "name": "opt_desks",
      "displayName": "Filter options: desks",
      "queryLines": [
        "-- Choices for the Desk dropdown. 'All' sorts first and turns the desk filter off\n",
        "-- in position_detail. Feeds no chart.\n",
        "SELECT desk FROM (\n",
        "  SELECT 'All' AS desk, 0 AS sort_key\n",
        "  UNION ALL\n",
        "  SELECT DISTINCT desk, 1 AS sort_key\n",
        "  FROM ${catalog}.${schema}.positions\n",
        ")\n",
        "ORDER BY sort_key, desk\n"
      ]
    },
    {
      "name": "opt_views",
      "displayName": "Filter options: view selector",
      "queryLines": [
        "-- Choices for the View Selector. Each value must equal a temp view name in dynamic_view,\n",
        "-- since IDENTIFIER resolves the string as a view. Add a view there before adding it here.\n",
        "SELECT view_name FROM VALUES ('by_region'), ('by_product'), ('by_desk') AS t(view_name)\n"
      ]
    },
    {
      "name": "opt_shock",
      "displayName": "Filter options: market shock",
      "queryLines": [
        "-- Fixed market shock levels in percent for the Market Shock dropdown.\n",
        "-- A number entry would work too. A dropdown keeps the demo to tested values.\n",
        "SELECT shock_pct FROM VALUES (-30), (-20), (-10), (0), (10), (20) AS t(shock_pct)\n",
        "ORDER BY shock_pct\n"
      ]
    },
    {
      "name": "opt_risk_category",
      "displayName": "Filter options: risk category",
      "queryLines": [
        "-- Choices for the Risk Category dropdown. 'All' shocks every factor in the region.\n",
        "SELECT risk_category FROM (\n",
        "  SELECT 'All' AS risk_category, 0 AS sort_key\n",
        "  UNION ALL\n",
        "  SELECT DISTINCT factor_category, 1 AS sort_key\n",
        "  FROM ${catalog}.${schema}.risk_factors\n",
        ")\n",
        "ORDER BY sort_key, risk_category\n"
      ]
    },
    {
      "name": "opt_measure",
      "displayName": "Filter options: measure",
      "queryLines": [
        "-- Choices for the Measure dropdown. Each value must match a WHEN branch in the\n",
        "-- portfolio_summary CASE. Anything else falls through to Stress impact.\n",
        "SELECT measure FROM VALUES ('Stress impact', 1), ('Risk-weighted exposure', 2), ('Notional', 3) AS t(measure, sort_key)\n",
        "ORDER BY sort_key\n"
      ]
    }
  ],
  "pages": [
    {
      "name": "portfolio_overview",
      "displayName": "Portfolio Overview",
      "pageType": "PAGE_TYPE_CANVAS",
      "layoutVersion": "GRID_V1",
      "layout": [
        {
          "widget": {
            "name": "header",
            "multilineTextboxSpec": {
              "lines": [
                "## Portfolio Analytics\n",
                "\n",
                "Pick a region, product type, desk and notional threshold. Each choice feeds parameterized SQL that builds temporary views at query time. The view selector switches the chart between three pre-built views."
              ]
            }
          },
          "position": {
            "x": 0,
            "y": 0,
            "width": 12,
            "height": 2
          }
        },
        {
          "widget": {
            "name": "filter_region",
            "queries": [
              {
                "name": "opt_region_q",
                "query": {
                  "datasetName": "opt_regions",
                  "fields": [
                    {
                      "name": "region",
                      "expression": "`region`"
                    }
                  ],
                  "disaggregated": false
                }
              },
              {
                "name": "p_summary_region",
                "query": {
                  "datasetName": "portfolio_summary",
                  "parameters": [
                    {
                      "name": "selected_region",
                      "keyword": "selected_region"
                    }
                  ],
                  "disaggregated": false
                }
              },
              {
                "name": "p_kpis_region",
                "query": {
                  "datasetName": "portfolio_kpis",
                  "parameters": [
                    {
                      "name": "selected_region",
                      "keyword": "selected_region"
                    }
                  ],
                  "disaggregated": false
                }
              },
              {
                "name": "p_detail_region",
                "query": {
                  "datasetName": "position_detail",
                  "parameters": [
                    {
                      "name": "selected_region",
                      "keyword": "selected_region"
                    }
                  ],
                  "disaggregated": false
                }
              },
              {
                "name": "p_scenario_selected_region",
                "query": {
                  "datasetName": "scenario_by_desk",
                  "parameters": [
                    {
                      "name": "selected_region",
                      "keyword": "selected_region"
                    }
                  ],
                  "disaggregated": false
                }
              }
            ],
            "spec": {
              "version": 2,
              "widgetType": "filter-single-select",
              "encodings": {
                "fields": [
                  {
                    "fieldName": "region",
                    "displayName": "Region",
                    "queryName": "opt_region_q"
                  },
                  {
                    "parameterName": "selected_region",
                    "queryName": "p_summary_region"
                  },
                  {
                    "parameterName": "selected_region",
                    "queryName": "p_kpis_region"
                  },
                  {
                    "parameterName": "selected_region",
                    "queryName": "p_detail_region"
                  },
                  {
                    "parameterName": "selected_region",
                    "queryName": "p_scenario_selected_region"
                  }
                ]
              },
              "selection": {
                "defaultSelection": {
                  "values": {
                    "dataType": "STRING",
                    "values": [
                      {
                        "value": "Americas"
                      }
                    ]
                  }
                }
              },
              "frame": {
                "showTitle": true,
                "title": "Region"
              }
            }
          },
          "position": {
            "x": 0,
            "y": 2,
            "width": 3,
            "height": 2
          }
        },
        {
          "widget": {
            "name": "filter_product",
            "queries": [
              {
                "name": "opt_product_q",
                "query": {
                  "datasetName": "opt_products",
                  "fields": [
                    {
                      "name": "product_type",
                      "expression": "`product_type`"
                    }
                  ],
                  "disaggregated": false
                }
              },
              {
                "name": "p_summary_product",
                "query": {
                  "datasetName": "portfolio_summary",
                  "parameters": [
                    {
                      "name": "selected_product",
                      "keyword": "selected_product"
                    }
                  ],
                  "disaggregated": false
                }
              },
              {
                "name": "p_kpis_product",
                "query": {
                  "datasetName": "portfolio_kpis",
                  "parameters": [
                    {
                      "name": "selected_product",
                      "keyword": "selected_product"
                    }
                  ],
                  "disaggregated": false
                }
              },
              {
                "name": "p_detail_product",
                "query": {
                  "datasetName": "position_detail",
                  "parameters": [
                    {
                      "name": "selected_product",
                      "keyword": "selected_product"
                    }
                  ],
                  "disaggregated": false
                }
              },
              {
                "name": "p_scenario_selected_product",
                "query": {
                  "datasetName": "scenario_by_desk",
                  "parameters": [
                    {
                      "name": "selected_product",
                      "keyword": "selected_product"
                    }
                  ],
                  "disaggregated": false
                }
              }
            ],
            "spec": {
              "version": 2,
              "widgetType": "filter-single-select",
              "encodings": {
                "fields": [
                  {
                    "fieldName": "product_type",
                    "displayName": "Product Type",
                    "queryName": "opt_product_q"
                  },
                  {
                    "parameterName": "selected_product",
                    "queryName": "p_summary_product"
                  },
                  {
                    "parameterName": "selected_product",
                    "queryName": "p_kpis_product"
                  },
                  {
                    "parameterName": "selected_product",
                    "queryName": "p_detail_product"
                  },
                  {
                    "parameterName": "selected_product",
                    "queryName": "p_scenario_selected_product"
                  }
                ]
              },
              "selection": {
                "defaultSelection": {
                  "values": {
                    "dataType": "STRING",
                    "values": [
                      {
                        "value": "Equities"
                      }
                    ]
                  }
                }
              },
              "frame": {
                "showTitle": true,
                "title": "Product Type"
              }
            }
          },
          "position": {
            "x": 3,
            "y": 2,
            "width": 3,
            "height": 2
          }
        },
        {
          "widget": {
            "name": "filter_desk",
            "queries": [
              {
                "name": "opt_desk_q",
                "query": {
                  "datasetName": "opt_desks",
                  "fields": [
                    {
                      "name": "desk",
                      "expression": "`desk`"
                    }
                  ],
                  "disaggregated": false
                }
              },
              {
                "name": "p_detail_desk",
                "query": {
                  "datasetName": "position_detail",
                  "parameters": [
                    {
                      "name": "selected_desk",
                      "keyword": "selected_desk"
                    }
                  ],
                  "disaggregated": false
                }
              }
            ],
            "spec": {
              "version": 2,
              "widgetType": "filter-single-select",
              "encodings": {
                "fields": [
                  {
                    "fieldName": "desk",
                    "displayName": "Desk",
                    "queryName": "opt_desk_q"
                  },
                  {
                    "parameterName": "selected_desk",
                    "queryName": "p_detail_desk"
                  }
                ]
              },
              "selection": {
                "defaultSelection": {
                  "values": {
                    "dataType": "STRING",
                    "values": [
                      {
                        "value": "All"
                      }
                    ]
                  }
                }
              },
              "frame": {
                "showTitle": true,
                "title": "Desk (detail table)"
              }
            }
          },
          "position": {
            "x": 6,
            "y": 2,
            "width": 3,
            "height": 2
          }
        },
        {
          "widget": {
            "name": "filter_min_notional",
            "queries": [
              {
                "name": "p_summary_notional",
                "query": {
                  "datasetName": "portfolio_summary",
                  "parameters": [
                    {
                      "name": "min_notional",
                      "keyword": "min_notional"
                    }
                  ],
                  "disaggregated": false
                }
              }
            ],
            "spec": {
              "version": 2,
              "widgetType": "filter-text-entry",
              "encodings": {
                "fields": [
                  {
                    "parameterName": "min_notional",
                    "queryName": "p_summary_notional"
                  }
                ]
              },
              "frame": {
                "showTitle": true,
                "title": "Min Notional (risk overlay)",
                "showDescription": true,
                "description": "Type any amount: 50000000, 50M, $50,000,000"
              }
            }
          },
          "position": {
            "x": 9,
            "y": 2,
            "width": 3,
            "height": 2
          }
        },
        {
          "widget": {
            "name": "kpi_total_notional",
            "queries": [
              {
                "name": "main_query",
                "query": {
                  "datasetName": "portfolio_kpis",
                  "fields": [
                    {
                      "name": "sum(total_notional)",
                      "expression": "SUM(`total_notional`)"
                    }
                  ],
                  "disaggregated": false
                }
              }
            ],
            "spec": {
              "version": 2,
              "widgetType": "counter",
              "encodings": {
                "value": {
                  "fieldName": "sum(total_notional)",
                  "displayName": "Total Notional",
                  "format": {
                    "type": "number-currency",
                    "currencyCode": "USD",
                    "abbreviation": "compact",
                    "decimalPlaces": {
                      "type": "max",
                      "places": 2
                    }
                  }
                }
              },
              "frame": {
                "showTitle": true,
                "title": "Total Notional",
                "showDescription": true,
                "description": "Selected region and product, trailing 24 months"
              }
            }
          },
          "position": {
            "x": 0,
            "y": 4,
            "width": 6,
            "height": 3
          }
        },
        {
          "widget": {
            "name": "kpi_total_pnl",
            "queries": [
              {
                "name": "main_query",
                "query": {
                  "datasetName": "portfolio_kpis",
                  "fields": [
                    {
                      "name": "sum(total_pnl)",
                      "expression": "SUM(`total_pnl`)"
                    }
                  ],
                  "disaggregated": false
                }
              }
            ],
            "spec": {
              "version": 2,
              "widgetType": "counter",
              "encodings": {
                "value": {
                  "fieldName": "sum(total_pnl)",
                  "displayName": "Total PnL",
                  "format": {
                    "type": "number-currency",
                    "currencyCode": "USD",
                    "abbreviation": "compact",
                    "decimalPlaces": {
                      "type": "max",
                      "places": 2
                    }
                  }
                }
              },
              "frame": {
                "showTitle": true,
                "title": "Total PnL",
                "showDescription": true,
                "description": "Selected region and product, trailing 24 months"
              }
            }
          },
          "position": {
            "x": 6,
            "y": 4,
            "width": 6,
            "height": 3
          }
        },
        {
          "widget": {
            "name": "filter_view_selector",
            "queries": [
              {
                "name": "opt_view_q",
                "query": {
                  "datasetName": "opt_views",
                  "fields": [
                    {
                      "name": "view_name",
                      "expression": "`view_name`"
                    }
                  ],
                  "disaggregated": false
                }
              },
              {
                "name": "p_dynamic_view",
                "query": {
                  "datasetName": "dynamic_view",
                  "parameters": [
                    {
                      "name": "view_name",
                      "keyword": "view_name"
                    }
                  ],
                  "disaggregated": false
                }
              }
            ],
            "spec": {
              "version": 2,
              "widgetType": "filter-single-select",
              "encodings": {
                "fields": [
                  {
                    "fieldName": "view_name",
                    "displayName": "View",
                    "queryName": "opt_view_q"
                  },
                  {
                    "parameterName": "view_name",
                    "queryName": "p_dynamic_view"
                  }
                ]
              },
              "selection": {
                "defaultSelection": {
                  "values": {
                    "dataType": "STRING",
                    "values": [
                      {
                        "value": "by_region"
                      }
                    ]
                  }
                }
              },
              "frame": {
                "showTitle": true,
                "title": "View Selector (runtime view switch)"
              }
            }
          },
          "position": {
            "x": 0,
            "y": 7,
            "width": 12,
            "height": 2
          }
        },
        {
          "widget": {
            "name": "chart_dynamic_view",
            "queries": [
              {
                "name": "main_query",
                "query": {
                  "datasetName": "dynamic_view",
                  "fields": [
                    {
                      "name": "dimension",
                      "expression": "`dimension`"
                    },
                    {
                      "name": "sum(total_notional)",
                      "expression": "SUM(`total_notional`)"
                    }
                  ],
                  "disaggregated": false
                }
              }
            ],
            "spec": {
              "version": 3,
              "widgetType": "bar",
              "encodings": {
                "x": {
                  "fieldName": "dimension",
                  "scale": {
                    "type": "categorical"
                  },
                  "displayName": "Grouping"
                },
                "y": {
                  "fieldName": "sum(total_notional)",
                  "scale": {
                    "type": "quantitative"
                  },
                  "displayName": "Total Notional",
                  "format": {
                    "type": "number-currency",
                    "currencyCode": "USD",
                    "abbreviation": "compact",
                    "decimalPlaces": {
                      "type": "max",
                      "places": 1
                    }
                  }
                }
              },
              "frame": {
                "showTitle": true,
                "title": "Total Notional by Selected View",
                "showDescription": true,
                "description": "Whole book. The SQL picks the view with IDENTIFIER(:view_name)"
              }
            }
          },
          "position": {
            "x": 0,
            "y": 9,
            "width": 12,
            "height": 6
          }
        },
        {
          "widget": {
            "name": "scenario_header",
            "multilineTextboxSpec": {
              "lines": [
                "### What-if scenario\n",
                "\n",
                "Pick a market shock, the risk factors it hits and the measure to show. A Unity Catalog function, stress_impact, applies the rule at query time. Only the two widgets below react. The tiles, the view chart and Position Detail stay the same."
              ]
            }
          },
          "position": {
            "x": 0,
            "y": 15,
            "width": 12,
            "height": 2
          }
        },
        {
          "widget": {
            "name": "filter_shock",
            "queries": [
              {
                "name": "opt_shock_pct_q",
                "query": {
                  "datasetName": "opt_shock",
                  "fields": [
                    {
                      "name": "shock_pct",
                      "expression": "`shock_pct`"
                    }
                  ],
                  "disaggregated": false
                }
              },
              {
                "name": "p_portfolio_summary_shock_pct",
                "query": {
                  "datasetName": "portfolio_summary",
                  "parameters": [
                    {
                      "name": "shock_pct",
                      "keyword": "shock_pct"
                    }
                  ],
                  "disaggregated": false
                }
              },
              {
                "name": "p_scenario_by_desk_shock_pct",
                "query": {
                  "datasetName": "scenario_by_desk",
                  "parameters": [
                    {
                      "name": "shock_pct",
                      "keyword": "shock_pct"
                    }
                  ],
                  "disaggregated": false
                }
              }
            ],
            "spec": {
              "version": 2,
              "widgetType": "filter-single-select",
              "encodings": {
                "fields": [
                  {
                    "fieldName": "shock_pct",
                    "displayName": "Market Shock (%)",
                    "queryName": "opt_shock_pct_q"
                  },
                  {
                    "parameterName": "shock_pct",
                    "queryName": "p_portfolio_summary_shock_pct"
                  },
                  {
                    "parameterName": "shock_pct",
                    "queryName": "p_scenario_by_desk_shock_pct"
                  }
                ]
              },
              "selection": {
                "defaultSelection": {
                  "values": {
                    "dataType": "INTEGER",
                    "values": [
                      {
                        "value": "-20"
                      }
                    ]
                  }
                }
              },
              "frame": {
                "showTitle": true,
                "title": "Market Shock (%)"
              }
            }
          },
          "position": {
            "x": 0,
            "y": 17,
            "width": 4,
            "height": 2
          }
        },
        {
          "widget": {
            "name": "filter_risk_category",
            "queries": [
              {
                "name": "opt_risk_category_q",
                "query": {
                  "datasetName": "opt_risk_category",
                  "fields": [
                    {
                      "name": "risk_category",
                      "expression": "`risk_category`"
                    }
                  ],
                  "disaggregated": false
                }
              },
              {
                "name": "p_portfolio_summary_risk_category",
                "query": {
                  "datasetName": "portfolio_summary",
                  "parameters": [
                    {
                      "name": "risk_category",
                      "keyword": "risk_category"
                    }
                  ],
                  "disaggregated": false
                }
              },
              {
                "name": "p_scenario_by_desk_risk_category",
                "query": {
                  "datasetName": "scenario_by_desk",
                  "parameters": [
                    {
                      "name": "risk_category",
                      "keyword": "risk_category"
                    }
                  ],
                  "disaggregated": false
                }
              }
            ],
            "spec": {
              "version": 2,
              "widgetType": "filter-single-select",
              "encodings": {
                "fields": [
                  {
                    "fieldName": "risk_category",
                    "displayName": "Risk Category",
                    "queryName": "opt_risk_category_q"
                  },
                  {
                    "parameterName": "risk_category",
                    "queryName": "p_portfolio_summary_risk_category"
                  },
                  {
                    "parameterName": "risk_category",
                    "queryName": "p_scenario_by_desk_risk_category"
                  }
                ]
              },
              "selection": {
                "defaultSelection": {
                  "values": {
                    "dataType": "STRING",
                    "values": [
                      {
                        "value": "All"
                      }
                    ]
                  }
                }
              },
              "frame": {
                "showTitle": true,
                "title": "Risk Category"
              }
            }
          },
          "position": {
            "x": 4,
            "y": 17,
            "width": 4,
            "height": 2
          }
        },
        {
          "widget": {
            "name": "filter_measure",
            "queries": [
              {
                "name": "opt_measure_q",
                "query": {
                  "datasetName": "opt_measure",
                  "fields": [
                    {
                      "name": "measure",
                      "expression": "`measure`"
                    }
                  ],
                  "disaggregated": false
                }
              },
              {
                "name": "p_portfolio_summary_measure",
                "query": {
                  "datasetName": "portfolio_summary",
                  "parameters": [
                    {
                      "name": "measure",
                      "keyword": "measure"
                    }
                  ],
                  "disaggregated": false
                }
              }
            ],
            "spec": {
              "version": 2,
              "widgetType": "filter-single-select",
              "encodings": {
                "fields": [
                  {
                    "fieldName": "measure",
                    "displayName": "Measure (Risk Overlay)",
                    "queryName": "opt_measure_q"
                  },
                  {
                    "parameterName": "measure",
                    "queryName": "p_portfolio_summary_measure"
                  }
                ]
              },
              "selection": {
                "defaultSelection": {
                  "values": {
                    "dataType": "STRING",
                    "values": [
                      {
                        "value": "Stress impact"
                      }
                    ]
                  }
                }
              },
              "frame": {
                "showTitle": true,
                "title": "Measure (Risk Overlay)"
              }
            }
          },
          "position": {
            "x": 8,
            "y": 17,
            "width": 4,
            "height": 2
          }
        },
        {
          "widget": {
            "name": "chart_stressed_pnl",
            "queries": [
              {
                "name": "main_query",
                "query": {
                  "datasetName": "scenario_by_desk",
                  "fields": [
                    {
                      "name": "desk",
                      "expression": "`desk`"
                    },
                    {
                      "name": "sum(base_pnl)",
                      "expression": "SUM(`base_pnl`)"
                    },
                    {
                      "name": "sum(stressed_pnl)",
                      "expression": "SUM(`stressed_pnl`)"
                    }
                  ],
                  "disaggregated": false
                }
              }
            ],
            "spec": {
              "version": 3,
              "widgetType": "bar",
              "encodings": {
                "x": {
                  "fieldName": "desk",
                  "scale": {
                    "type": "categorical"
                  },
                  "displayName": "Desk"
                },
                "y": {
                  "scale": {
                    "type": "quantitative"
                  },
                  "format": {
                    "type": "number-currency",
                    "currencyCode": "USD",
                    "abbreviation": "compact",
                    "decimalPlaces": {
                      "type": "max",
                      "places": 1
                    }
                  },
                  "fields": [
                    {
                      "fieldName": "sum(base_pnl)",
                      "displayName": "Base PnL"
                    },
                    {
                      "fieldName": "sum(stressed_pnl)",
                      "displayName": "Stressed PnL"
                    }
                  ]
                }
              },
              "mark": {
                "layout": "group"
              },
              "frame": {
                "showTitle": true,
                "title": "Stressed PnL by Desk",
                "showDescription": true,
                "description": "Base PnL vs PnL after the shock, selected region and product"
              }
            }
          },
          "position": {
            "x": 0,
            "y": 19,
            "width": 5,
            "height": 8
          }
        },
        {
          "widget": {
            "name": "table_risk_overlay",
            "queries": [
              {
                "name": "main_query",
                "query": {
                  "datasetName": "portfolio_summary",
                  "fields": [
                    {
                      "name": "factor_category",
                      "expression": "`factor_category`"
                    },
                    {
                      "name": "factor_name",
                      "expression": "`factor_name`"
                    },
                    {
                      "name": "desk",
                      "expression": "`desk`"
                    },
                    {
                      "name": "sensitivity",
                      "expression": "`sensitivity`"
                    },
                    {
                      "name": "total_notional",
                      "expression": "`total_notional`"
                    },
                    {
                      "name": "risk_weighted_exposure",
                      "expression": "`risk_weighted_exposure`"
                    },
                    {
                      "name": "total_pnl",
                      "expression": "`total_pnl`"
                    },
                    {
                      "name": "position_count",
                      "expression": "`position_count`"
                    },
                    {
                      "name": "stress_impact",
                      "expression": "`stress_impact`"
                    },
                    {
                      "name": "measure_name",
                      "expression": "`measure_name`"
                    },
                    {
                      "name": "selected_measure",
                      "expression": "`selected_measure`"
                    },
                    {
                      "name": "min_notional_applied",
                      "expression": "`min_notional_applied`"
                    }
                  ],
                  "disaggregated": true
                }
              }
            ],
            "spec": {
              "version": 2,
              "widgetType": "table",
              "encodings": {
                "columns": [
                  {
                    "fieldName": "factor_category",
                    "displayName": "Category"
                  },
                  {
                    "fieldName": "factor_name",
                    "displayName": "Risk Factor"
                  },
                  {
                    "fieldName": "desk",
                    "displayName": "Desk"
                  },
                  {
                    "fieldName": "sensitivity",
                    "displayName": "Sensitivity"
                  },
                  {
                    "fieldName": "total_notional",
                    "displayName": "Notional",
                    "format": {
                      "type": "number-currency",
                      "currencyCode": "USD",
                      "abbreviation": "compact",
                      "decimalPlaces": {
                        "type": "max",
                        "places": 1
                      }
                    }
                  },
                  {
                    "fieldName": "risk_weighted_exposure",
                    "displayName": "Risk-Weighted Exposure",
                    "format": {
                      "type": "number-currency",
                      "currencyCode": "USD",
                      "abbreviation": "compact",
                      "decimalPlaces": {
                        "type": "max",
                        "places": 1
                      }
                    }
                  },
                  {
                    "fieldName": "total_pnl",
                    "displayName": "PnL",
                    "format": {
                      "type": "number-currency",
                      "currencyCode": "USD",
                      "abbreviation": "compact",
                      "decimalPlaces": {
                        "type": "max",
                        "places": 1
                      }
                    }
                  },
                  {
                    "fieldName": "stress_impact",
                    "displayName": "Stress Impact",
                    "format": {
                      "type": "number-currency",
                      "currencyCode": "USD",
                      "abbreviation": "compact",
                      "decimalPlaces": {
                        "type": "max",
                        "places": 1
                      }
                    }
                  },
                  {
                    "fieldName": "measure_name",
                    "displayName": "Measure"
                  },
                  {
                    "fieldName": "selected_measure",
                    "displayName": "Selected Measure",
                    "format": {
                      "type": "number-currency",
                      "currencyCode": "USD",
                      "abbreviation": "compact",
                      "decimalPlaces": {
                        "type": "max",
                        "places": 1
                      }
                    }
                  },
                  {
                    "fieldName": "min_notional_applied",
                    "displayName": "Min Notional applied",
                    "format": {
                      "type": "number-currency",
                      "currencyCode": "USD",
                      "abbreviation": "compact",
                      "decimalPlaces": {
                        "type": "max",
                        "places": 1
                      }
                    }
                  }
                ]
              },
              "frame": {
                "showTitle": true,
                "title": "Risk Overlay",
                "showDescription": true,
                "description": "Filtered positions x risk factors in scope, per factor and desk. Measure picks the Selected Measure column. Rows below Min Notional are hidden"
              }
            }
          },
          "position": {
            "x": 5,
            "y": 19,
            "width": 7,
            "height": 8
          }
        },
        {
          "widget": {
            "name": "table_position_detail",
            "queries": [
              {
                "name": "main_query",
                "query": {
                  "datasetName": "position_detail",
                  "fields": [
                    {
                      "name": "position_id",
                      "expression": "`position_id`"
                    },
                    {
                      "name": "region",
                      "expression": "`region`"
                    },
                    {
                      "name": "product_type",
                      "expression": "`product_type`"
                    },
                    {
                      "name": "desk",
                      "expression": "`desk`"
                    },
                    {
                      "name": "desk_head",
                      "expression": "`desk_head`"
                    },
                    {
                      "name": "cost_center",
                      "expression": "`cost_center`"
                    },
                    {
                      "name": "counterparty",
                      "expression": "`counterparty`"
                    },
                    {
                      "name": "notional_value",
                      "expression": "`notional_value`"
                    },
                    {
                      "name": "market_value",
                      "expression": "`market_value`"
                    },
                    {
                      "name": "pnl",
                      "expression": "`pnl`"
                    },
                    {
                      "name": "trade_date",
                      "expression": "`trade_date`"
                    },
                    {
                      "name": "maturity_date",
                      "expression": "`maturity_date`"
                    }
                  ],
                  "disaggregated": true
                }
              }
            ],
            "spec": {
              "version": 2,
              "widgetType": "table",
              "encodings": {
                "columns": [
                  {
                    "fieldName": "position_id",
                    "displayName": "Position ID"
                  },
                  {
                    "fieldName": "region",
                    "displayName": "Region"
                  },
                  {
                    "fieldName": "product_type",
                    "displayName": "Product"
                  },
                  {
                    "fieldName": "desk",
                    "displayName": "Desk"
                  },
                  {
                    "fieldName": "desk_head",
                    "displayName": "Desk Head"
                  },
                  {
                    "fieldName": "cost_center",
                    "displayName": "Cost Center"
                  },
                  {
                    "fieldName": "counterparty",
                    "displayName": "Counterparty"
                  },
                  {
                    "fieldName": "notional_value",
                    "displayName": "Notional",
                    "format": {
                      "type": "number-currency",
                      "currencyCode": "USD",
                      "abbreviation": "compact",
                      "decimalPlaces": {
                        "type": "max",
                        "places": 2
                      }
                    }
                  },
                  {
                    "fieldName": "market_value",
                    "displayName": "Market Value",
                    "format": {
                      "type": "number-currency",
                      "currencyCode": "USD",
                      "abbreviation": "compact",
                      "decimalPlaces": {
                        "type": "max",
                        "places": 2
                      }
                    }
                  },
                  {
                    "fieldName": "pnl",
                    "displayName": "PnL",
                    "format": {
                      "type": "number-currency",
                      "currencyCode": "USD",
                      "abbreviation": "compact",
                      "decimalPlaces": {
                        "type": "max",
                        "places": 2
                      }
                    }
                  },
                  {
                    "fieldName": "trade_date",
                    "displayName": "Trade Date"
                  },
                  {
                    "fieldName": "maturity_date",
                    "displayName": "Maturity Date"
                  }
                ]
              },
              "frame": {
                "showTitle": true,
                "title": "Position Detail",
                "showDescription": true,
                "description": "Positions joined to desk reference data (desk head, cost center)"
              }
            }
          },
          "position": {
            "x": 0,
            "y": 27,
            "width": 12,
            "height": 8
          }
        }
      ]
    }
  ],
  "uiSettings": {
    "theme": {
      "canvasBackgroundColor": {
        "light": "#F7F7F5",
        "dark": "#1F272D"
      },
      "widgetBackgroundColor": {
        "light": "#FFFFFF",
        "dark": "#11171C"
      },
      "widgetBorderColor": {
        "light": "#FFFFFF",
        "dark": "#11171C"
      },
      "fontColor": {
        "light": "#1B2A3A",
        "dark": "#E8ECF0"
      },
      "selectionColor": {
        "light": "#2272B4",
        "dark": "#8ACAFF"
      },
      "visualizationColors": [
        "#003F5C",
        "#594E90",
        "#BC4C96",
        "#FF5F66",
        "#FFA600",
        "#4E79A7",
        "#76B7B2"
      ],
      "widgetHeaderAlignment": "LEFT"
    }
  }
}
'''

w = WorkspaceClient()


def pick_warehouse() -> str:
    found = list(w.warehouses.list())
    for wh in found:
        if wh.enable_serverless_compute and wh.state and wh.state.value == "RUNNING":
            return wh.id
    for wh in found:
        if wh.enable_serverless_compute:
            return wh.id
    if found:
        return found[0].id
    raise RuntimeError("No SQL warehouse visible. Create one, or put its ID in the warehouse_id widget.")


WAREHOUSE_ID = dbutils.widgets.get("warehouse_id").strip() or pick_warehouse()
serialized = json.dumps(json.loads(DASHBOARD_JSON.replace(PH, FQ)))
display_name = f"Portfolio Analytics ({SCHEMA})"
parent = f"/Workspace/Users/{w.current_user.me().user_name}/portfolio-analytics-demo"
w.workspace.mkdirs(parent)

# REST calls keep this working across SDK versions in different runtimes.
try:
    status = w.api_client.do("GET", "/api/2.0/workspace/get-status",
                             query={"path": f"{parent}/{display_name}.lvdash.json"})
    dashboard_id = status["resource_id"]
except NotFound:
    dashboard_id = None

body = {"display_name": display_name, "serialized_dashboard": serialized, "warehouse_id": WAREHOUSE_ID}
if dashboard_id:
    w.api_client.do("PATCH", f"/api/2.0/lakeview/dashboards/{dashboard_id}", body=body)
    print(f"Updated dashboard {dashboard_id}")
else:
    dashboard_id = w.api_client.do("POST", "/api/2.0/lakeview/dashboards",
                                   body=body | {"parent_path": parent})["dashboard_id"]
    print(f"Created dashboard {dashboard_id}")
w.api_client.do("POST", f"/api/2.0/lakeview/dashboards/{dashboard_id}/published",
                body={"embed_credentials": True, "warehouse_id": WAREHOUSE_ID})

# COMMAND ----------

# MAGIC %md ## 5. Check and links

# COMMAND ----------

counts = {t: spark.sql(f"SELECT COUNT(*) FROM {FQ}.{t}").first()[0]
          for t in ("positions", "risk_factors", "reference_data")}
assert counts == {"positions": 500, "risk_factors": 100, "reference_data": 48}, counts
orphans = spark.sql(f"""SELECT COUNT(*) FROM {FQ}.positions p LEFT JOIN {FQ}.reference_data r
                       USING (desk, region, product_type) WHERE r.desk IS NULL""").first()[0]
assert orphans == 0, f"{orphans} positions have no desk row"
impact = spark.sql(f"SELECT {FQ}.stress_impact(1000000, 0.5, -20, 4)").first()[0]
assert abs(impact + 25000) < 0.01, impact

host = w.config.host.rstrip("/")
print(f"Checks passed: {counts}")
print(f"Warehouse:  {WAREHOUSE_ID}")
print(f"Draft:      {host}/dashboardsv3/{dashboard_id}")
print(f"Published:  {host}/dashboardsv3/{dashboard_id}/published")
dbutils.notebook.exit(json.dumps({"dashboard_id": dashboard_id, "counts": counts}))
